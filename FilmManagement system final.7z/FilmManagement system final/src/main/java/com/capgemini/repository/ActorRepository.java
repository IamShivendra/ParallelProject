package com.capgemini.repository;

import java.util.List;

import com.capgemini.pojo.Actor;

public interface ActorRepository {
	boolean save(Actor actor);
	List<Actor> searchByName(String firstName,String lastName);
	List<Actor> searchByGender(String Gender);
	boolean deleteActor(Actor actor);
	boolean modifyActor(Actor actor);
	
}
