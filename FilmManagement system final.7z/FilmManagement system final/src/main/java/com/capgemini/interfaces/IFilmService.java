package com.capgemini.interfaces;

import java.util.List;

import com.capgemini.pojo.Actor;
import com.capgemini.pojo.Category;
import com.capgemini.pojo.Film;

public interface IFilmService {
	String addFilm(Film film);
	String modifyFilm(Film film);
	String deleteFilm(Film film);
	List<Film> searchFilmByTitle(String title);
	List<Film> searchFilmByCategory(String category);
	List<Film> searchFilmByRating(short rating);
	List<Film> searchFilmByLanguage(String lang);
	List<Film> searchFilmByActor(Actor actor);
	List<Film> searchFilmByRealeaseYear(short year);

}
